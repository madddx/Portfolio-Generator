Optional: put extra images here and refer to them as assets/your-image.jpg in the admin page.
Images you upload in the editor are stored inside portfolio-data.js, so this folder can stay empty.
