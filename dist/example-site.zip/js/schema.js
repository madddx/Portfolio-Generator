/*  Shared schema: styles, sections, social networks, defaults, normalisation.
    Used by the generated site, its admin page and the generator itself.   */
(function (root) {
  'use strict';

  // ── Styles ────────────────────────────────────────────────────────────
  // `fonts` is the Google Fonts query string the style needs.
  // Filled in by build.mjs from themes/*/theme.json (newest first).
  var STYLES = [{"id":"slate","name":"Slate","blurb":"Clean and professional. Each section is a tidy panel on a soft grey page, like a well-kept profile.","released":"2026-11-22","fonts":"family=Inter:wght@400;500;600;700","accent":{"light":"#1f5fe0","dark":"#6ea1ff"},"swatch":{"light":["#eceff4","#0f1722","#1f5fe0"],"dark":["#0e1217","#f1f4f9","#6ea1ff"]},"thumb":"<svg viewBox=\"0 0 120 76\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><rect width=\"120\" height=\"76\" fill=\"{bg}\"/><rect width=\"120\" height=\"9\" fill=\"{ink}\" fill-opacity=\".06\"/><rect x=\"10\" y=\"3.5\" width=\"14\" height=\"2.5\" rx=\"1.2\" fill=\"{ink}\" opacity=\".6\"/><rect x=\"10\" y=\"14\" width=\"100\" height=\"26\" rx=\"4\" fill=\"{ink}\" fill-opacity=\".06\" stroke=\"{ink}\" stroke-opacity=\".14\"/><rect x=\"15\" y=\"19\" width=\"16\" height=\"16\" rx=\"3\" fill=\"{ac}\"/><rect x=\"38\" y=\"20\" width=\"36\" height=\"4.5\" rx=\"2\" fill=\"{ink}\"/><rect x=\"38\" y=\"28\" width=\"26\" height=\"3\" rx=\"1.5\" fill=\"{ink}\" opacity=\".45\"/><rect x=\"10\" y=\"44\" width=\"100\" height=\"26\" rx=\"4\" fill=\"{ink}\" fill-opacity=\".06\" stroke=\"{ink}\" stroke-opacity=\".14\"/><rect x=\"15\" y=\"49\" width=\"22\" height=\"3.5\" rx=\"1.7\" fill=\"{ink}\"/><rect x=\"15\" y=\"57\" width=\"26\" height=\"8\" rx=\"2\" fill=\"{ac}\" fill-opacity=\".25\"/><rect x=\"45\" y=\"57\" width=\"26\" height=\"8\" rx=\"2\" fill=\"{ac}\" fill-opacity=\".25\"/></svg>"},{"id":"aurora","name":"Aurora","blurb":"Glowing, technical and dark-first. A grid of light behind a rounded profile card.","released":"2026-11-01","fonts":"family=Syne:wght@600;700;800&family=DM+Sans:ital,wght@0,400;0,500;0,700;1,400&family=DM+Mono:wght@400;500","accent":{"light":"#0b6fd6","dark":"#2ad4ff"},"swatch":{"light":["#f2f6fb","#0d1b2e","#0b6fd6"],"dark":["#070b12","#e8eef8","#2ad4ff"]},"thumb":"<svg viewBox=\"0 0 120 76\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><rect width=\"120\" height=\"76\" fill=\"{bg}\"/><circle cx=\"92\" cy=\"26\" r=\"30\" fill=\"{ac}\" opacity=\".18\"/><rect x=\"10\" y=\"18\" width=\"48\" height=\"6\" rx=\"3\" fill=\"{ink}\"/><rect x=\"10\" y=\"29\" width=\"34\" height=\"6\" rx=\"3\" fill=\"{ink}\"/><rect x=\"10\" y=\"43\" width=\"42\" height=\"3\" rx=\"1.5\" fill=\"{ink}\" opacity=\".55\"/><rect x=\"10\" y=\"52\" width=\"22\" height=\"9\" rx=\"4\" fill=\"{ac}\"/><rect x=\"74\" y=\"14\" width=\"34\" height=\"46\" rx=\"8\" fill=\"{ac}\"/></svg>"},{"id":"folio","name":"Folio","blurb":"Quiet and typographic. Your name stays pinned on the left while the work scrolls past.","released":"2026-11-01","fonts":"family=Instrument+Serif:ital@0;1&family=Instrument+Sans:ital,wght@0,400;0,500;0,600;1,400","accent":{"light":"#2a3cff","dark":"#8b96ff"},"swatch":{"light":["#f6f7f9","#14161c","#2a3cff"],"dark":["#0f1115","#eceef3","#8b96ff"]},"thumb":"<svg viewBox=\"0 0 120 76\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><rect width=\"120\" height=\"76\" fill=\"{bg}\"/><rect width=\"30\" height=\"76\" fill=\"{ink}\" opacity=\".06\"/><circle cx=\"10\" cy=\"12\" r=\"4\" fill=\"none\" stroke=\"{ac}\"/><rect x=\"6\" y=\"26\" width=\"16\" height=\"2.5\" rx=\"1\" fill=\"{ink}\" opacity=\".55\"/><rect x=\"6\" y=\"33\" width=\"12\" height=\"2.5\" rx=\"1\" fill=\"{ink}\" opacity=\".55\"/><rect x=\"6\" y=\"40\" width=\"15\" height=\"2.5\" rx=\"1\" fill=\"{ink}\" opacity=\".55\"/><circle cx=\"46\" cy=\"18\" r=\"7\" fill=\"{ac}\" opacity=\".7\"/><rect x=\"38\" y=\"32\" width=\"64\" height=\"9\" rx=\"1.5\" fill=\"{ink}\"/><rect x=\"38\" y=\"46\" width=\"36\" height=\"4\" rx=\"1\" fill=\"{ink}\" opacity=\".55\"/><rect x=\"38\" y=\"56\" width=\"52\" height=\"2.5\" rx=\"1\" fill=\"{ink}\" opacity=\".3\"/></svg>"},{"id":"brutal","name":"Brutal","blurb":"Thick outlines, hard shadows and flat colour. Loud on purpose.","released":"2026-11-01","fonts":"family=Space+Grotesk:wght@500;700&family=Space+Mono:wght@400;700","accent":{"light":"#ffd23f","dark":"#ffd23f"},"swatch":{"light":["#fffdf5","#111111","#ffd23f"],"dark":["#111111","#fffdf5","#ffd23f"]},"thumb":"<svg viewBox=\"0 0 120 76\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><rect width=\"120\" height=\"76\" fill=\"{bg}\"/><rect x=\"8\" y=\"12\" width=\"52\" height=\"10\" fill=\"{ink}\"/><rect x=\"8\" y=\"26\" width=\"30\" height=\"9\" fill=\"{ac}\" stroke=\"{ink}\" stroke-width=\"2\"/><rect x=\"8\" y=\"42\" width=\"38\" height=\"3\" fill=\"{ink}\" opacity=\".55\"/><rect x=\"73\" y=\"17\" width=\"38\" height=\"46\" fill=\"{ink}\"/><rect x=\"70\" y=\"13\" width=\"38\" height=\"46\" fill=\"{ac}\" stroke=\"{ink}\" stroke-width=\"2.5\"/><rect x=\"8\" y=\"54\" width=\"26\" height=\"10\" fill=\"{bg}\" stroke=\"{ink}\" stroke-width=\"2\"/><rect x=\"10\" y=\"56\" width=\"26\" height=\"10\" fill=\"none\"/></svg>"},{"id":"bloom","name":"Bloom","blurb":"Soft, round and friendly. Pastel surfaces with a centred introduction.","released":"2026-11-01","fonts":"family=Bricolage+Grotesque:opsz,wght@12..96,500;700;800&family=Manrope:wght@400;500;600;700","accent":{"light":"#7a4dff","dark":"#b79cff"},"swatch":{"light":["#fbf4ff","#2a1f45","#7a4dff"],"dark":["#171128","#f1eaff","#b79cff"]},"thumb":"<svg viewBox=\"0 0 120 76\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><rect width=\"120\" height=\"76\" fill=\"{bg}\"/><circle cx=\"20\" cy=\"10\" r=\"24\" fill=\"{ac}\" opacity=\".14\"/><circle cx=\"104\" cy=\"60\" r=\"26\" fill=\"{ac}\" opacity=\".12\"/><rect x=\"26\" y=\"5\" width=\"68\" height=\"9\" rx=\"4.5\" fill=\"{ink}\" opacity=\".12\"/><circle cx=\"60\" cy=\"27\" r=\"10\" fill=\"{ac}\"/><rect x=\"38\" y=\"42\" width=\"44\" height=\"6\" rx=\"3\" fill=\"{ink}\"/><rect x=\"46\" y=\"52\" width=\"28\" height=\"3\" rx=\"1.5\" fill=\"{ink}\" opacity=\".55\"/><rect x=\"14\" y=\"62\" width=\"28\" height=\"10\" rx=\"5\" fill=\"{ac}\" opacity=\".35\"/><rect x=\"46\" y=\"62\" width=\"28\" height=\"10\" rx=\"5\" fill=\"{ac}\" opacity=\".6\"/><rect x=\"78\" y=\"62\" width=\"28\" height=\"10\" rx=\"5\" fill=\"{ac}\" opacity=\".35\"/></svg>"},{"id":"terminal","name":"Terminal","blurb":"Everything in monospace, each section a shell window. For people who live in the console.","released":"2026-11-01","fonts":"family=JetBrains+Mono:ital,wght@0,400;0,500;0,700;1,400","accent":{"light":"#0a7d3b","dark":"#4ade80"},"swatch":{"light":["#eef2ec","#14231a","#0a7d3b"],"dark":["#0a0f0c","#d6f5df","#4ade80"]},"thumb":"<svg viewBox=\"0 0 120 76\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><rect width=\"120\" height=\"76\" fill=\"{bg}\"/><rect x=\"8\" y=\"8\" width=\"62\" height=\"60\" rx=\"3\" fill=\"{ink}\" opacity=\".08\" stroke=\"{ink}\" stroke-opacity=\".3\"/><circle cx=\"14\" cy=\"14\" r=\"1.8\" fill=\"#ff5f56\"/><circle cx=\"20\" cy=\"14\" r=\"1.8\" fill=\"#ffbd2e\"/><circle cx=\"26\" cy=\"14\" r=\"1.8\" fill=\"#27c93f\"/><rect x=\"14\" y=\"24\" width=\"18\" height=\"3\" rx=\"1\" fill=\"{ac}\"/><rect x=\"14\" y=\"32\" width=\"46\" height=\"6\" rx=\"1\" fill=\"{ink}\"/><rect x=\"14\" y=\"43\" width=\"30\" height=\"3\" rx=\"1\" fill=\"{ink}\" opacity=\".55\"/><rect x=\"14\" y=\"54\" width=\"20\" height=\"7\" rx=\"1.5\" fill=\"{ac}\"/><rect x=\"78\" y=\"14\" width=\"34\" height=\"26\" rx=\"3\" fill=\"none\" stroke=\"{ink}\" stroke-opacity=\".4\"/><rect x=\"78\" y=\"46\" width=\"34\" height=\"3\" fill=\"{ac}\" opacity=\".8\"/></svg>"}];
  var DEFAULT_STYLE = 'aurora';

  // ── Sections (order = default page order) ─────────────────────────────
  var SECTIONS = [
    { id: 'about',          title: 'About' },
    { id: 'experience',     title: 'Experience' },
    { id: 'projects',       title: 'Projects' },
    { id: 'skills',         title: 'Skills' },
    { id: 'education',      title: 'Education' },
    { id: 'certifications', title: 'Certifications' },
    { id: 'publications',   title: 'Publications' },
    { id: 'awards',         title: 'Awards' },
    { id: 'learning',       title: 'Courses' },
    { id: 'links',          title: 'Links' },
    { id: 'contact',        title: 'Contact' }
  ];

  // ── Social networks (order = display order) ───────────────────────────
  var SOCIALS = [
    { id: 'linkedin',  label: 'LinkedIn',        icon: 'fab fa-linkedin-in',   ph: 'https://www.linkedin.com/in/you' },
    { id: 'github',    label: 'GitHub',          icon: 'fab fa-github',        ph: 'https://github.com/you' },
    { id: 'x',         label: 'X (Twitter)',     icon: 'fab fa-x-twitter',     ph: 'https://x.com/you' },
    { id: 'instagram', label: 'Instagram',       icon: 'fab fa-instagram',     ph: 'https://instagram.com/you' },
    { id: 'youtube',   label: 'YouTube',         icon: 'fab fa-youtube',       ph: 'https://youtube.com/@you' },
    { id: 'website',   label: 'Website',         icon: 'fas fa-globe',         ph: 'https://yoursite.com' },
    { id: 'medium',    label: 'Medium',          icon: 'fab fa-medium',        ph: 'https://medium.com/@you' },
    { id: 'behance',   label: 'Behance',         icon: 'fab fa-behance',       ph: 'https://behance.net/you' },
    { id: 'dribbble',  label: 'Dribbble',        icon: 'fab fa-dribbble',      ph: 'https://dribbble.com/you' },
    { id: 'kaggle',    label: 'Kaggle',          icon: 'fab fa-kaggle',        ph: 'https://kaggle.com/you' },
    { id: 'leetcode',  label: 'LeetCode',        icon: 'fas fa-code',          ph: 'https://leetcode.com/u/you' },
    { id: 'scholar',   label: 'Google Scholar',  icon: 'fas fa-graduation-cap',ph: 'https://scholar.google.com/citations?user=…' },
    { id: 'orcid',     label: 'ORCID',           icon: 'fab fa-orcid',         ph: 'https://orcid.org/0000-0000-0000-0000' },
    { id: 'researchgate', label: 'ResearchGate', icon: 'fab fa-researchgate',  ph: 'https://researchgate.net/profile/you' },
    { id: 'telegram',  label: 'Telegram',        icon: 'fab fa-telegram',      ph: 'https://t.me/you' }
  ];

  // Icon guessing so users never have to type Font Awesome class names.
  var SKILL_ICONS = {
    'python':'fab fa-python','javascript':'fab fa-js','js':'fab fa-js','react':'fab fa-react','react.js':'fab fa-react',
    'node':'fab fa-node-js','node.js':'fab fa-node-js','nodejs':'fab fa-node-js','html':'fab fa-html5','html5':'fab fa-html5',
    'css':'fab fa-css3-alt','css3':'fab fa-css3-alt','java':'fab fa-java','php':'fab fa-php','angular':'fab fa-angular',
    'vue':'fab fa-vuejs','vue.js':'fab fa-vuejs','bootstrap':'fab fa-bootstrap','sass':'fab fa-sass','git':'fab fa-git-alt',
    'github':'fab fa-github','gitlab':'fab fa-gitlab','docker':'fab fa-docker','aws':'fab fa-aws','linux':'fab fa-linux',
    'figma':'fab fa-figma','npm':'fab fa-npm','swift':'fab fa-swift','rust':'fab fa-rust','go':'fab fa-golang','golang':'fab fa-golang',
    'android':'fab fa-android','wordpress':'fab fa-wordpress','jira':'fab fa-jira','slack':'fab fa-slack','unity':'fab fa-unity',
    'azure':'fab fa-microsoft','microsoft':'fab fa-microsoft','google cloud':'fab fa-google','gcp':'fab fa-google',
    'sql':'fas fa-database','mysql':'fas fa-database','postgresql':'fas fa-database','mongodb':'fas fa-database','databricks':'fas fa-database',
    'pyspark':'fas fa-bolt','spark':'fas fa-bolt','machine learning':'fas fa-brain','deep learning':'fas fa-brain','ai':'fas fa-brain',
    'c':'fas fa-code','c++':'fas fa-code','c#':'fas fa-code','typescript':'fas fa-code','kotlin':'fas fa-code'
  };
  var HOST_ICONS = [
    [/github\.com/, 'fab fa-github'], [/linkedin\.com/, 'fab fa-linkedin-in'], [/(twitter|x)\.com/, 'fab fa-x-twitter'],
    [/instagram\.com/, 'fab fa-instagram'], [/youtube\.com|youtu\.be/, 'fab fa-youtube'], [/medium\.com/, 'fab fa-medium'],
    [/behance\.net/, 'fab fa-behance'], [/dribbble\.com/, 'fab fa-dribbble'], [/kaggle\.com/, 'fab fa-kaggle'],
    [/orcid\.org/, 'fab fa-orcid'], [/researchgate\.net/, 'fab fa-researchgate'], [/scholar\.google/, 'fas fa-graduation-cap'],
    [/leetcode\.com/, 'fas fa-code'], [/drive\.google|docs\.google/, 'fab fa-google-drive'], [/t\.me|telegram/, 'fab fa-telegram'],
    [/stackoverflow\.com/, 'fab fa-stack-overflow'], [/codepen\.io/, 'fab fa-codepen'], [/coursera\.org|udemy\.com|edx\.org/, 'fas fa-graduation-cap']
  ];

  function skillIcon(name) { return SKILL_ICONS[String(name || '').trim().toLowerCase()] || ''; }
  function urlIcon(url) {
    var u = String(url || '').toLowerCase();
    for (var i = 0; i < HOST_ICONS.length; i++) if (HOST_ICONS[i][0].test(u)) return HOST_ICONS[i][1];
    return 'fas fa-link';
  }

  // ── Defaults ──────────────────────────────────────────────────────────
  function emptyData() {
    return {
      version: 1,
      meta: { title: '', description: '', year: '' },
      design: { style: DEFAULT_STYLE, mode: 'auto', accent: '', toggle: true },
      sections: SECTIONS.map(function (s) { return { id: s.id, title: s.title, visible: true }; }),
      hero: { name: '', headline: '', typed: [], bio: '', photo: '', location: '', resume: '', stats: [], badges: [] },
      socials: {},
      about: { paragraphs: [], facts: [], interests: [] },
      education: [], experience: [], projects: [], skills: [], certifications: [],
      publications: [], awards: [], learning: [], links: [],
      contact: { intro: '', email: '', phone: '', location: '', form: true }
    };
  }

  function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }
  function merge(base, src) {
    if (!isObj(src)) return base;
    Object.keys(base).forEach(function (k) {
      if (!(k in src) || src[k] == null) return;
      if (isObj(base[k]) && k !== 'socials') base[k] = merge(base[k], src[k]);
      else if (Array.isArray(base[k])) base[k] = Array.isArray(src[k]) ? src[k] : base[k];
      else base[k] = src[k];
    });
    if (isObj(base.socials) && isObj(src.socials)) base.socials = src.socials;
    return base;
  }

  // Fills in anything missing so older/hand-edited files still render.
  function normalize(input) {
    var d = merge(emptyData(), input || {});
    var known = {}, out = [];
    (d.sections || []).forEach(function (s) {
      var def = SECTIONS.filter(function (x) { return x.id === s.id; })[0];
      if (!def || known[s.id]) return;
      known[s.id] = 1;
      out.push({ id: s.id, title: (s.title || def.title), visible: s.visible !== false });
    });
    SECTIONS.forEach(function (def) {
      if (!known[def.id]) out.push({ id: def.id, title: def.title, visible: true });
    });
    d.sections = out;
    if (!STYLES.some(function (s) { return s.id === d.design.style; })) d.design.style = DEFAULT_STYLE;
    if (['light', 'dark', 'auto'].indexOf(d.design.mode) < 0) d.design.mode = 'auto';
    return d;
  }

  // Parses the contents of portfolio-data.js (or plain JSON).
  function parseDataFile(text) {
    var t = String(text || '').trim();
    var m = t.match(/window\.PORTFOLIO_DATA\s*=\s*([\s\S]*?);?\s*$/);
    if (m) t = m[1].replace(/;\s*$/, '');
    return normalize(JSON.parse(t));
  }
  function serializeDataFile(data) {
    return '/* Your portfolio content. Edit it with admin.html, then replace this file. */\n' +
           'window.PORTFOLIO_DATA = ' + JSON.stringify(data, null, 2) + ';\n';
  }

  root.PF = { STYLES: STYLES, SECTIONS: SECTIONS, SOCIALS: SOCIALS, emptyData: emptyData, normalize: normalize,
              parseDataFile: parseDataFile, serializeDataFile: serializeDataFile, skillIcon: skillIcon, urlIcon: urlIcon };
})(typeof window !== 'undefined' ? window : globalThis);
