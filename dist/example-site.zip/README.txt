Your portfolio website — Nila Raman
======================================

See it:      open index.html in your browser.
Publish it:  upload this whole folder to any static host.
             - Netlify:  drag the folder onto app.netlify.com/drop
             - Vercel, GitHub Pages, Cloudflare Pages: deploy the folder as it is.

Windows says the zip is blocked, or a file is "potentially harmful"?
  It is only Windows being careful with downloaded files. Right-click the .zip,
  choose Properties, tick "Unblock", press OK, then extract it again.
  Never double-click portfolio-data.js — it is just your content. Open index.html or admin.html instead.

Change something later (no need to come back to the generator)
  1. Open admin.html — from this folder, or at yoursite.com/admin.html once published.
  2. Edit, add or remove anything. The preview updates as you type.
  3. Press "Save changes". Your browser downloads a new portfolio-data.js.
  4. Replace the old portfolio-data.js in this folder with the new one and publish again.

Good to know
  - admin.html only prepares a new data file. It cannot change your live site by itself,
    so it is safe to leave online. Delete it if you would rather not publish it.
  - Everything you wrote and every photo lives in portfolio-data.js.
  - css/themes/ holds every style, so you can switch styles later from the admin page.
